library(shiny); library(DT)
ui <- fluidPage(
  selectInput("dataset", label = "Dataset", choices = ls("package:datasets")),
  verbatimTextOutput("summary"),
  DTOutput("table")
)
server <- function(input, output, session) {
  dataset <- reactive(get(input$dataset, "package:datasets"))
  output$summary <- renderPrint(summary(dataset()))
  output$table <- renderDT(datatable(dataset()) )
}
shinyApp(ui = ui, server = server)